Popeye arcade game sound code (c) Nintendo 1982
ZX Spectrum rewrite by Hikaru/Intense in 2018


Technical information
---------------------

The player has two entry points, listed here with offsets from the compile/load address. The
player uses the stack to load/store AY channel information, so interrupts have to be disabled
when either location is called.

+0: pesound.init, resets the AY and the player, call once in the beginning
+3: pesound.run, actual sound player code, call once every frame

The following registers are used by the player: BC,DE,HL,AF,IX.

The player is controlled by three external variables. As long as pesound.run is being called
 constantly, the player watches the state of these variables and plays the appropriate songs
/sound effects. The effect variables for channels B and C only accept codes of sound effects
 that are designed to play in their respective channels.

ext_music: Sets a new song to play
ext_sfx_b: Sets a new channel B sound effect to play
ext_sfx_c: Sets a new channel C sound effect to play

The actual memory locations of the controlling variables, as well as the player compile 
address, can be set in /src/config.asm.

The player commonly returns 0 in external variables to indicate that it has processed the 
request. An exception to this is if an attempt is made to set an ingame song while another 
ingame song was playing. In that case, the value of ext_music would be left unchanged until 
a 'checkpoint' is reached in the music (see below), whereupon the new song would be set to 
play and ext_music would be set to 0.

Additionally, ext_music is set to 1 when the current song has ended (doesn't apply to ingame
songs). In this way, it is possible to wait for a song to end simply by monitoring the state
of ext_music.

Because the player doesn't perform strict checking on its input values in the controlling 
variables, it is recommended to only use the music/effect codes as provided here.


Brief instructions
------------------

Set up the locations of the controlling variables and the player compile address as needed. 
If you are using build.bat to generate a binary file, this can be done in /src/config.asm. 
Otherwise, you can do it on your own using these as example.

In your program, call pesound.init once in the beginning. Afterwards, call pesound.run once 
every frame. The intended use is within an IM2 interrupt routine but it is also possible to 
call on its own. Make sure interrupts are disabled during both of these calls!

Once this is done, use the controlling variables to set the music and sound effects. Check 
the state of ext_music periodically for the value 1 to appear if you want to test whether a 
regular song has finished playing.

The value 255 will disable the currently playing song when set in ext_music, and mute the 
respective AY channels when set in ext_sfx_b or ext_sfx_c.


Music information
-----------------

There are two types of music in Popeye.

* Regular music: 2 or 3 channels, plays once. Can be changed to another song anytime without 
limitations.

* Ingame music: 1 channel, plays repeatedly (looping). Changes to different ingame songs must
occur at specific 'checkpoints' in the currently playing ingame song that denote endings of
musical patterns, and so are not guaranteed to happen immediately after a new ingame song
was set in ext_music. This does not apply to changing to a regular song from an ingame one,
in that case the regular song will start playing as soon as it is set, as per the norm.

Despite the terminology used here, the distinction between these types of music is primarily
in the way they are handled by the player, and not necessarily literal. For instance, one of
the regular songs (Spinach) is in fact used 'ingame' during gameplay.

Regardless of the currently playing song, it can be switched off using the value 255 at any 
time.

The available songs and their codes are listed below.

.----------------------------------------------.
| Ingame                                       |
|----------------------------------------------|
|  2 | Lv1 main                                |
|  3 | Lv2 main                                |
|  4 | Lv3 main                                |
|  5 | Lv1, Situation: Bucket on Bluto's head  |
|  6 | Situation: Pickup item is sinking       |
|  7 | Situation: Bluto is chasing Popeye      |
|----------------------------------------------|
| Regular                                      |
|----------------------------------------------|
|  8 | Spinach, normal tempo                   |
|  9 | Spinach, faster tempo                   |
| 10 | Spinach, fastest tempo                  |
| 11 | Lv1 intro                               |
| 12 | Lv1 clear                               |
| 13 | Lv2 clear                               |
| 14 | Lv3 intro                               |
| 15 | Title                                   |
| 16 | Game loop clear (Lv3 clear)             |
'----------------------------------------------'

The ingame Situational songs (5,6,7) are set in the arcade game whenever the described 
conditions are in effect. When this is no longer the case, the songs change back to the main
theme for the current level. The original priority for these seems to be 5>6>7, but this has
no influence on this rewritten version of the player, and is rather something that might be
considered on the user side instead.

There are three codes for Spinach at different tempos (8,9,10). Presumably, this is related 
to the difficulty level and/or the number of game loops completed.

Game loop clear (16) is actually the ending part of Title (15), played at a slower tempo.


Sound effects information
-------------------------

The sound effects in Popeye are played back using channels B and C of the AY.

Each of the sound effect routines in Popeye is set up to use a single fixed AY channel for 
playback. As such, there are two distinct groups of channel B and channel C sound effects. 
The way this assignment is done appears to be based upon the idea of making sure that the 
more-important sound effects (e.g. those that inform the game player of dangers) can always 
be heard and are never interrupted by the less-important ones.

There is a number of special 'Heart' sound effects (after the items picked up in Lv1),
short melodies played in channel C typically when a collectible item dropped by Olive is
picked up.

Channels B and C can be individually silenced by setting the value 255 in either ext_sfx_b 
or ext_sfx_c respectively.

The available sound effects and their codes are listed below.

.-----------------------------------------------------------------------------------------.
| Channel B sound effects                                                                 |
|-----------------------------------------------------------------------------------------|
|  1 | Bluto attacks by jumping down on the lower floor                                   |
|  2 | Bluto attacks by jumping, or sweeping his hand from above floor                    |
|  3 | Popeye breaks a can thrown by Bluto and/or the Sea Hag                             |
|  4 | Skull dropped by the Sea Hag jumps around, second loop and afterwards              |
|-----------------------------------------------------------------------------------------|
| Channel C sound effects                                                                 |
|-----------------------------------------------------------------------------------------|
|  5 | Popeye is hit and falls into the water                                             |
|  6 | Bluto bounces against the wall after being hit by Popeye and falls into the water  |
|  7 | Bluto jumps in place angrily after removing the bucket dropped on his head         |
|  8 | Bluto flies horizontally after being hit by Popeye                                 |
|  9 | Lv1, Popeye hits the punching bag                                                  |
| 10 | Lv1 intro, Bluto 'glides with a proposal' towards Olive                            |
| 11 | Lv3, generic eagle sound (?), is also used when the eagle is punched               |
| 12 | Popeye jumps down from above floor                                                 |
| 13 | Popeye attacks with a punch                                                        |
| 14 | Popeye walks, alternates between 2 frequencies each time                           |
| 15 | Popeye walks up/down the stairs                                                    |
|-----------------------------------------------------------------------------------------|
| Channel C Heart effects                                                                 |
|-----------------------------------------------------------------------------------------|
| 16 | Extra life                                                                         |
| 17 | Lv1, item picked up, alternates between two effects                                |
| 18 | Same as above                                                                      |
| 19 | Lv2, item picked up                                                                |
| 20 | Lv3, item picked up                                                                |
| 21 | Unknown                                                                            |
| 22 | Unknown                                                                            |
| 23 | Unknown, unreferenced in the code, appears similar to a Lv1 item pickup effect     |
'-----------------------------------------------------------------------------------------'

Level 1 Heart effect codes (17 and 18) have the exact same behavior when set in ext_sfx_c. 
The player sets one of the two level 1 item pickup effects to play, and internally switches 
to the other one.
Levels 2 and 3 each use a single item pickup effect.

It is unknown if Heart effects 21, 22 and 23 are actually used in the arcade game. Of these,
21 and 22 are referenced in the game code, but 23 appears to only exist as data.