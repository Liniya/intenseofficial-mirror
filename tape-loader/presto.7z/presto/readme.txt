PRESTO V2


Description

Presto is a ZX Spectrum tape loader with the ability to play Vortex Tracker II AY music while loading.

The loader acts like a simplified LOAD""CODE substitute, taking address/length from tape headers and ignoring 
file names. The loader uses the standard-speed 'ZX Spectrum ROM' scheme and supports loading data packed with 
Pletter 0.5c by XL2S Entertainment (http://xl2s.eu.pn/pletter.html), for which a customized decompressor is 
included. 128K loading is supported for packed data (non-overlapping).


General notes

On init, the provided VTII song is converted into another format suitable for realtime playback, and this data 
is stored in 128K pages. It is possible to designate how many and which pages should be used for the converted 
data. Pay special attention to memory usage as the resulting data can get very large!
Due to the fact that some time is spent converting the song data, you might need to delay loading the subsequent
 data blocks depending on the song length. Songs will always loop to the beginning regardless of VTII loop 
settings.

After the init step, components of the Presto loader are installed in two separate memory areas. The 'main' 
block is about 450 bytes situated close to 65535 in page 0, the 'resident' block is about 250 bytes starting 
from 23296.

This program uses IM2 with I=#3B and will therefore crash on 128K machines with attached poorly-designed 
peripheral hardware. This is the intended behavior.


Brief instructions

set RAMTOP to 24999 and below. Load the Presto loader main code at 43776, and the song data at 47616. Call Init,
 then use LoadCode / LoadPacked / LoadPackedLast as needed. Optionally call AYMute in the end.


Loader function description

Some functions accept numeric arguments in BASIC in the form PRINT USR FunctionAddress,Arg1,Arg2,...ArgN. In 
these cases, the PRINT USR would not actually print anything on the screen.

Init
43776

Initializes the loader and converts the provided VTII song. Should be called once before the rest of the 
functions can be used. It is expected that the song data is already present in the memory at the address 47616 
when calling this function.
Both plain data and Pletter-packed VTII modules are supported. In VTII, the modules should be saved without 
including the player code since the latter is already included in Presto.

The Init function accepts up to 5 numeric arguments in BASIC, which are interpreted as 128K pages that can be 
used for holding the converted song data. Without arguments, all 128K pages are considered to be available, used
 starting from page 1 sequentially (1,3,4,6,7).

On exit, 43776 will hold the number of pages used for the converted song data, and 43777 will hold the address 
of the last used byte in the last used page.

LoadCode
65527

Loads a regular code block. Loading address and length are taken from the header.

LoadPacked
65518

Loads a Pletter-packed code block. Without arguments in BASIC, the loading algorithm is as follows:
- Load the packed data at Loader-DataLength
- Unpack the data to the address specified in the header

If a numeric argument is provided in BASIC, it is interpreted as the 128K destination page number and a 
different loading algorithm is used:
- Load the data at RAMTOP+1
- Switch to the destination page
- Unpack the data to the address specified in the header

In the latter case, it is expected that RAMTOP+DataLength is less than UnpackAddress, and is less than 49152 if 
the page number is not 0.

LoadPackedLast
65515

Loads a packed code block with a special algorithm:
- Load the packed data at Loader-DataLength
- Move it closer towards the 'end of memory' (within some ~32 bytes from 65535)
- Unpack to RAMTOP+1
- Finally, move the unpacked data to the address specified in the header

The intended use is for unpacking large data blocks that require the unpacking address to be set as far away as 
possible from the source packed data. For blocks that are originally located adjacent or close to the loader and
 65535, make sure that RAMTOP+1 is at least 256 bytes less than the destination address of the original block. 
Note that the latter type of blocks cannot be loaded using LoadCode.

Caution: this operation overwrites the loader, after which it cannot be used anymore. For this reason, AYMute is
 called once before proceeding.

AYMute
65521

Silences the output from the AY. Except for LoadPackedLast, the loading functions do not mute the AY by 
themselves because AY register values are stored and output differentially, and therefore this might lead to 
unexpected effects in the music ('dropping out sounds') upon loading subsequent blocks.


(c) Intense 2017