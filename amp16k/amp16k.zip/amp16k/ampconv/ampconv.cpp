// ampconv by Hikaru/Intense in 2020
// Public Domain

#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>

unsigned char *xm = nullptr;


int get_word(int offset)
{
	return *(unsigned short*)(xm+offset);
}


int get_dword(int offset)
{
	return *(int*)(xm+offset);
}


void cleanup(void)
{
	free(xm);
}


int main(int argc, char* argv[])
{
	if(argc < 2 || argc > 3)
	{
		printf("ampconv by Hikaru/Intense in 2020\n");
		printf("Usage: ampconv infile.xm [outfile.asm]\n");
		exit(0);
	}

	FILE *file = fopen(argv[1], "rb");
	if(!file)
	{
		printf("ampconv: can't open file %s\n", argv[1]);
		exit(-1);
	}

	fseek(file, 0, SEEK_END);
	int size = ftell(file);
	fseek(file, 0, SEEK_SET);

	xm = (unsigned char*)malloc(size);
	fread(xm, size, 1, file);
	fclose(file);

	atexit(cleanup);

	int song_length = get_word(60+4);
	int restart_position = get_word(60+6);
	int channels = get_word(60+8);
	int patterns = get_word(60+10);
	int default_tempo = get_word(60+16);

	if(memcmp(xm, "Extended Module: ", 17) || get_word(58) != 0x104 || !song_length || !patterns)
	{
		printf("ampconv: unsupported file format or empty module\n");
		exit(-1);
	}

	if(channels < 4)
	{
		printf("ampconv: XM module must have 4 or more channels\n");
		exit(-1);
	}

	char name[1024] = {0};
	strcpy(name, argv[argc-1]);
	if (argc < 3) strcpy(name+strlen(name)-2, "asm");

	file = fopen(name,"wt");

	fprintf(file, "\tMODULE AMP_Song\n\nPatternDataOffset\n\tDW PatternData-PatternList\n\nPatternList\n");

	for(int i=0; i<song_length; i++)
	{
		if(i == restart_position) fprintf(file, "PatternListLoop\n");
		fprintf(file, "\tDW PT%2.2X-PatternData\n", xm[60+20+i]);
	}
	fprintf(file, "\tDW PatternListLoop-$-2\n\nPatternData\n");

	const int amp_pw[8] = { 1,3,7,15,31,63,127,255 };
	int pat_p = 60+20+256;
	for(int p=0; p<patterns; p++)
	{
		bool pat_used = memchr(xm+60+20, p, song_length);

		int amp_speed = default_tempo;
		int amp_inst[4] = {0};

		int rows = get_word(pat_p+5);
		pat_p += get_dword(pat_p);

		for(int r=0; r<rows; r++)
		{
			int row[8] = {0};
			int row_p = 0;

			int amp_drum = 0;
			int note_map = 0;

			for(int c=0; c<channels; c++)
			{
				// read .XM pattern row data
				int xm_note = 0,
				    xm_inst = 0,
				    xm_eff  = 0,
				    xm_par  = 0;

				int c_map = xm[pat_p++];
				if (c_map < 0x80)
				{
					xm_note = c_map;
					c_map = 0x1E;
				}

				if (c_map & 0x01) xm_note = xm[pat_p++];
				if (c_map & 0x02) xm_inst = xm[pat_p++];
				if (c_map & 0x04) pat_p++;					// XM volume is not used
				if (c_map & 0x08) xm_eff  = xm[pat_p++];
				if (c_map & 0x10) xm_par  = xm[pat_p++];

				if(r == 0 && xm_eff == 0x0F && xm_par < 0x20)			// speed: check row 0 only
					amp_speed = xm_par;

				// convert to AMP row data
				if (xm_note)
				{
					if (xm_inst == 9)					// drum
					{
						if (amp_drum == 0) amp_drum = std::max(std::min(xm_note-37+2, 9), 2);
						xm_note = 97;	// set rest in case this is a tone channel
					}
					if (c < 4)
					{
						int amp_note = xm_note;
						if (amp_note == 97) amp_note = 0, xm_inst = 0;	// rest

						if (xm_inst && amp_inst[c] != xm_inst)
						{
							amp_inst[c] = xm_inst;			// note + pw
							row[row_p++] = amp_note|0x80;
							row[row_p++] = amp_pw[std::min(xm_inst-1, 7)];
						}
						else
							row[row_p++] = amp_note;		// note

						note_map |= 0x80 >> c;
					}
				}
			}

			// write AMP row to .ASM file
			if (pat_used)
			{
				if (r == 0) fprintf(file, "PT%2.2X\n\tDB %d\n", p, amp_speed);

				fprintf(file, "\tDB #%2.2X", note_map | amp_drum);
				for (int rp = 0; rp < row_p; rp++)
					fprintf(file, ",#%2.2X", row[rp]);
				fprintf(file, "\n");
			}
		}
		if (pat_used) fprintf(file,"\tDB 1\n\n");	// end of AMP pattern
	}

	fprintf(file,"\tENDMODULE\n");
	fclose(file);

	exit(0);
}
